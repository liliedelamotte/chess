// ldelamotte17@georgefox.edu
// Assignment 8
// 2019-04-06


#include "Game.h"
#import <string>
using namespace std;

int main(int argc, char* argv[]) {

    Game::initialize();

    return 0;

}