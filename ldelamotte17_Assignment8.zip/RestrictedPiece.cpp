// ldelamotte17@georgefox.edu
// Assignment 8
// 2019-04-06


#include "RestrictedPiece.h"
#include "Player.h"
#include "Square.h"

bool RestrictedPiece::moveTo(Square& location, Player& byPlayer) {
    /* todo */
    return false;
}

bool RestrictedPiece::hasMoved() {
    return _moved;
}