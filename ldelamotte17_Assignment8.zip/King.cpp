// ldelamotte17@georgefox.edu
// Assignment 8
// 2019-04-06


#include "King.h"
#include "Square.h"

bool King::canMoveTo(Square& location) {
    /* todo */
    return false;
}

string King::toString() {
    return "K";
}