// ldelamotte17@georgefox.edu
// Assignment 8
// 2019-04-06


#include "Knight.h"
#include "Square.h"

bool Knight::canMoveTo(Square& location) {
    /* todo */
    return false;
}

string Knight::toString() {
    return "N";
}