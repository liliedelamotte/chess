// ldelamotte17@georgefox.edu
// Assignment 8
// 2019-04-06


#include "Queen.h"
#include "Square.h"

bool Queen::canMoveTo(Square& location) {
    /* todo */
    return false;
}

string Queen::toString() {
    return "Q";
}