// ldelamotte17@georgefox.edu
// Assignment 7
// 2019-03-23


#include "King.h"
#include "Square.h"

King::~King() {
    delete this;
}

bool King::canMoveTo(Square& location) {
    /* todo */
    return false;
}

string King::toString() {
    return "K";
}