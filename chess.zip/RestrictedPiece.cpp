// ldelamotte17@georgefox.edu
// Assignment 7
// 2019-03-23


#include "RestrictedPiece.h"
#include "Player.h"
#include "Square.h"

bool RestrictedPiece::moveTo(Square& location, Player& byPlayer) {
    /* todo */
    return false;
}

bool RestrictedPiece::hasMoved() {
    return _moved;
}